﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace TipCalculator
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			CalculateTips();
		}

		private void TipButton_Click(object sender, RoutedEventArgs e)
		{
			if (sender is Button button)
			{
				string buttonText = button.Content.ToString();
				tipTextBox.Text = buttonText.Replace("%", "");
			}
		}

		private void CalculateTips(object sender = null, TextChangedEventArgs e = null)
		{
			CalculateTips();
		}

		private void CalculateTips()
		{
			try
			{
				double bill = 0;
				double.TryParse(billTextBox?.Text ?? "0", out bill);

				double tipPercent = 0;
				double.TryParse(tipTextBox?.Text ?? "15", out tipPercent);

				int people = 1;
				int.TryParse(peopleTextBox?.Text ?? "1", out people);
				if (people < 1) people = 1;

				double tipAmount = bill * (tipPercent / 100);
				double totalAmount = bill + tipAmount;
				double perPerson = totalAmount / people;

				if (tipResult != null) tipResult.Text = $"{tipAmount:F2} ₽";
				if (totalResult != null) totalResult.Text = $"{totalAmount:F2} ₽";
				if (perPersonResult != null) perPersonResult.Text = $"{perPerson:F2} ₽";
			}
			catch (Exception)
			{
				if (tipResult != null) tipResult.Text = "0 ₽";
				if (totalResult != null) totalResult.Text = "0 ₽";
				if (perPersonResult != null) perPersonResult.Text = "0 ₽";
			}
		}

		private void ClearButton_Click(object sender, RoutedEventArgs e) 
		{
			billTextBox.Text = "0";
			tipTextBox.Text = "15";
			peopleTextBox.Text = "1";
			CalculateTips();


		}
	}
}